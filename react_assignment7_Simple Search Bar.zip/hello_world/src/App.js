import { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import Welcome from './components/Welcome';
import Clock from './components/Clock';
import LoginControl from './components/LoginControl';
import Blog from './components/Blog';
import Form from './components/Form';
import Search from './components/Search';
import List from './components/List';

function App() {
  const [flag, setFlag] = useState(true);
  const [searchTerm, setSearchTerm] = useState()
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const userInfo = {
    firstname:"Alif Haiqal",
    lastname: "bin Zainal Zahari",
  };

  const posts = [
    {
      id: 1,
      title: "Harry Potter",
      content: "",
    },
    {
      id: 2,
      title: "Lord of the Rings",
      content: "",
    },
    {
      id: 3,
      title: "The Power",
      content: "",
    },
    {
      id: 4,
      title: "Why We're Polarized",
      content: "",
    },
    {
      id: 5,
      title: "The Lincoln Highway",
      content: "",
    },
    {
      id: 6,
      title: "The Ministry for the Future",
      content: "",
    },
    {
      id: 7,
      title: "How the World Really Works",
      content: "",
    },
    {
      id: 8,
      title: "Where the Crawdads Sing",
      content: "",
    },
    {
      id: 9,
      title: "Verity",
      content: "",
    },
  ];

  const filterList = posts.filter((item) => {
    return item.title.toLowerCase().includes(searchTerm.toLowerCase());
});

  // const toggle = () => {
  //   console.log("Toggle Clicked");
  //   setFlag(!flag);
  // };

  return (
    <>
      {/* <button onClick={() => setFlag(!flag)}>Toggle Clock Component </button> */}
      {/* {flag ? <Clock /> : "No Clock component"} */}
      {/* <Welcome user="Alif Haiqal" />
      <Welcome user="bin" />
      <Welcome user="Zainal Zahari" /> */}
      {/* <LoginControl/> */}
      {/* <Blog posts={posts} /> */}
      {/* <Form /> */}
      <Search searchTerm={searchTerm} handleSearch={handleSearch}/>
      <List list={filterList}/>
    </>
  );
}

export default App;
