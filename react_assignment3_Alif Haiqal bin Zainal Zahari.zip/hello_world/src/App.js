import logo from './logo.svg';
import './App.css';
import Welcome from './components/Welcome';
import Clock from './components/Clock';

function App() {
  const userInfo = {
    firstname:"Alif Haiqal",
    lastname: "bin Zainal Zahari",
  };

  return (
    <>
      <Clock />
      {/* <Welcome user="Alif Haiqal" />
      <Welcome user="bin" />
      <Welcome user="Zainal Zahari" /> */}
    </>
  );
}

export default App;
