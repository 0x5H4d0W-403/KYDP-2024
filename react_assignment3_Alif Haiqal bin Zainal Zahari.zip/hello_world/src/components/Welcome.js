function Welcome(props) {
    console.log(props);
    return <h1>Welcome{props.user} from welcome component</h1>;
}

export default Welcome;