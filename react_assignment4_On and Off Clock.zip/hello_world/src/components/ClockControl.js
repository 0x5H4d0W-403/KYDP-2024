// ClockControl.js
import React, { useState } from "react";
import Clock from "./Clock";

function ClockControl() {
    const [isClockOn, setIsClockOn] = useState(true);

    const toggleClock = () => {
        setIsClockOn(!isClockOn);
    };

    return (
        <div>
            <h1>Time Now:</h1>
            <button onClick={toggleClock}>
                {isClockOn ? "Turn off clock" : "Turn on clock"}
            </button>
            <div>
                {isClockOn ? <Clock /> : <h2>Clock is off</h2>}
            </div>
        </div>
    );
}

export default ClockControl;
