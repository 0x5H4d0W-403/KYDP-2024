// App.js
import React from "react";
import "./App.css";
import ClockControl from "./components/ClockControl";

function App() {
    return (
        <div className="App">
            <ClockControl />
        </div>
    );
}

export default App;
