function Blog(props) { 
    const content = props.posts.map((post) => (
        <Post key={post.id} post={post} />
    ));
    
    return <div>{content}</div>;
}

function Post(props) {
    const { id, title, content } = props.post;
    return (
        <div style={{ marginBottom: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
                <span style={{ fontWeight: 'bold', fontSize: '24px', marginRight: '10px' }}>#{id}</span>
                <span style={{ fontWeight: 'bold', fontSize: '24px' }}>{title}</span>
            </div>
            <div style={{ fontSize: '18px', color: '#555' }}>{content}</div>
        </div>
    );
}

export default Blog;
