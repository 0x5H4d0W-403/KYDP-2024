import { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import Welcome from './components/Welcome';
import Clock from './components/Clock';
import LoginControl from './components/LoginControl';
import Blog from './components/Blog';

function App() {
  const [flag, setFlag] = useState(true);
  const userInfo = {
    firstname:"Alif Haiqal",
    lastname: "bin Zainal Zahari",
  };

  const posts = [
    {
      id: 1,
      title: "-Introduction",
      content: "I'm Alif Haiqal!",
    },
    {
      id: 2,
      title: "-Interests",
      content: "I love reading books and playing games",
    },
    {
      id: 3,
      title: "-Age",
      content: "I'm currently 22 years old",
    },
  ]
  // const toggle = () => {
  //   console.log("Toggle Clicked");
  //   setFlag(!flag);
  // };

  return (
    <>
      {/* <button onClick={() => setFlag(!flag)}>Toggle Clock Component </button> */}
      {/* {flag ? <Clock /> : "No Clock component"} */}
      {/* <Welcome user="Alif Haiqal" />
      <Welcome user="bin" />
      <Welcome user="Zainal Zahari" /> */}
      {/* <LoginControl/> */}
      <Blog posts={posts} />
    </>
  );
}

export default App;
